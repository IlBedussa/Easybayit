import type { APIRoute } from 'astro';
export const GET: APIRoute = () => new Response('ok', { headers: { 'content-type': 'text/plain', 'cache-control': 'no-store' } });
